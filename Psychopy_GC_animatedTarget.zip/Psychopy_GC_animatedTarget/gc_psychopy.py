######## Psychopy demo with the custom Psychopy Core Graphics
# If you need to use a screen units other than 'pix', which we do not recommend as the gaze coordinates 
# returned by pylink is in 'pix' units, please make sure to properly set the size of the cursor and the
# position of the gaze. However, the calibration/validation routine should work fine regardless of the 
# screen units.

# import libraries
import pylink, numpy, os, random
from EyeLinkCoreGraphicsPsychoPy import EyeLinkCoreGraphicsPsychoPy
from psychopy import visual, core, event, gui, monitors

#### STEP I: get subject info with GUI ########################################################
expInfo = {'SubjectNO':'00', 'SubjectInitials':'TEST'}
dlg = gui.DlgFromDict(dictionary=expInfo, title="GC Example")
if dlg.OK == False: core.quit()  # user pressed cancel

#### SETP II: established a link to the tracker ###############################################
dummyMode = False # If in Dummy Mode, press ESCAPE to skip calibration/validataion
if not dummyMode:
    tk = pylink.EyeLink('100.1.1.1')
else:
    tk = pylink.EyeLink(None)

#### STEP III: Open an EDF data file EARLY ####################################################
dataFolder = os.getcwd() + '/edfData/'
dataFileName = expInfo['SubjectNO'] + '_' + expInfo['SubjectInitials'] + '.EDF'

# Note that for Eyelink 1000/II, he file name cannot exceeds 8 characters
# we need to open eyelink data files early so as to record as much info as possible
tk.openDataFile(dataFileName)
# add personalized header (preamble text)
tk.sendCommand("add_file_preamble_text 'Psychopy GC demo'") 

#### STEP IV: Initialize custom graphics for camera setup & drift correction ##################
scnWidth, scnHeight = (1280, 1024)
# you MUST specify the physical properties of your monitor first, otherwise you won't be able to properly use
# different screen "units" in psychopy 
mon = monitors.Monitor('myMac15', width=32.0, distance=57.0)
mon.setSizePix((scnWidth, scnHeight))
win = visual.Window((scnWidth, scnHeight), fullscr=True, monitor=mon,
                    color=[0,0,0], units='pix', allowGUI=False)
# this functional calls our custom calibration routin "EyeLinkCoreGraphicsPsychopy.py"
genv = EyeLinkCoreGraphicsPsychoPy(tk, win)
pylink.openGraphicsEx(genv)

#### STEP V: Set up the tracker ################################################################
# we need to put the tracker in offline mode before we change its configrations
tk.setOfflineMode()
# sampling rate
tk.sendCommand('sample_rate 500') 
# 0-> standard, 1-> sensitive [Manual: section ??]
tk.sendCommand('select_parser_configuration 0') 
# make sure the tracker knows the physical resolution of the subject display
tk.sendCommand("screen_pixel_coords = 0 0 %d %d" % (scnWidth-1, scnHeight-1))
# stamp display resolution in EDF data file for Eyelink Data Viewer integration
tk.sendMessage("DISPLAY_COORDS = 0 0 %d %d" % (scnWidth-1, scnHeight-1))
# Set the tracker to record Event Data in "GAZE" (or "HREF") coordinates
tk.sendCommand("recording_parse_type = GAZE") 
# Here we show how to use the "setXXXX" command to control the tracker, see the "EyeLink" section of the pylink manual.
# specify the calibration type, H3, HV3, HV5, HV13 (HV = horiztonal/vertical)
tk.sendCommand("calibration_type = HV9")
# tk.setCalibrationType('HV9')
# color theme of the calibration display
pylink.setCalibrationColors((255,255,255), (0,0,0))
# allow buttons on the gamepad to accept calibration/dirft check target 
tk.sendCommand("button_function 1 'accept_target_fixation'")
# custom animation calibration target
#pylink.setCalibrationAnimationTarget()  # this wil require changing the calibration routine

# set link and file contents
eyelinkVer = tk.getTrackerVersion()
if eyelinkVer >=3: # Eyelink 1000/1000 plus
    tk.sendCommand("file_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,MESSAGE,BUTTON,INPUT")
    tk.sendCommand("link_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,BUTTON,INPUT")
    tk.sendCommand("file_sample_data = LEFT,RIGHT,GAZE,GAZERES,AREA,HREF,PUPIL,STATUS,INPUT,HTARGET")
    tk.sendCommand("link_sample_data = LEFT,RIGHT,GAZE,GAZERES,AREA,HREF,PUPIL,STATUS,INPUT,HTARGET")
else: # Eyelink II
    tk.sendCommand("file_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,MESSAGE,BUTTON,INPUT")
    tk.sendCommand("link_event_filter = LEFT,RIGHT,FIXATION,SACCADE,BLINK,BUTTON,INPUT")
    tk.sendCommand("file_sample_data = LEFT,RIGHT,GAZE,GAZERES,AREA,HREF,PUPIL,STATUS,INPUT")
    tk.sendCommand("link_sample_data = LEFT,RIGHT,GAZE,GAZERES,AREA,HREF,PUPIL,STATUS,INPUT")

#### OPTIONAL: a little helper for backdropping image to the Host PC #################################
# this function is slow and is not recommended for large displays.
def array2List(scnHeight, scnWidth, scnShoot):
    rv = []
    for y in range(scnHeight):
        line = []
        for x in range(scnWidth):
            pix = scnShoot.getpixel((x,y))
            line.append(pix)
        rv.append(line)
    return rv

#### STEP VI: specify all possible experimental cells #################################################
# one may read in s spreadsheet that defines the experimentl cells; usually, a simple list-like the one below
# should also do the job; if we need tweenty trials, simple go with "new_list = trials[:]*10", then 
# random.shuffle(new_list) 
trials = [['CondA', 'sacrmeto.jpg'],
          ['CondB', 'sacrmeto.jpg']]

#### SETP VII: a helper to run a single trial #########################################################
# 
def runTrial(pars):
    """ pars corresponds to a row in the trial list"""
    
    # retrieve paramters from the trial list
    cond, pic = pars 
    
    # load the image to display
    img = visual.ImageStim(win, image=pic)
   
    # take the tracker offline
    tk.setOfflineMode()
    pylink.pumpDelay(50)
    
    # send the "TRIALID" message to mark the start of a trial 
    tk.sendMessage('TRIALID')
    
    # record_status_message : show some info on the host PC
    tk.sendCommand("record_status_message 'Cond %s'"% cond)
    
    # drift check
    try:
        err = tk.doDriftCorrect(win.size[0]/2, win.size[1]/2,1,1)
    except:
        tk.doTrackerSetup()    
        
    # show the image and gaze-contingent cursor
    cursor = visual.GratingStim(win, tex='none', mask='gauss', size=60,color=[-1.0,1.0,-1.0])
    
    # here we draw the image in the back buffer and grab a "screenshot" before the stimuli is actually displayed
    img.draw()  
    img2drop = win.getMovieFrame(buffer="back") # grab a screenshoot of the back buffer to backdrop    
    # backdroping the whole display is slow, we commented out the lines below for optimal performance
    # x = array2List(scnHeight, scnWidth, img2drop)
    # tk.sendCommand('clear_screen 0')
    # tk.bitmapBackdrop(scnWidth, scnHeight, x, 0, 0, scnWidth, scnHeight, 0, 0, pylink.BX_LIGHTEN)
    
    # Note that backdrop only shows an image on the host display, to overly gaze on the image in Data Viewer, you need to
    # save the "screenshot" and send a !V message to the tracker    
    # save the screenshot; later on we will send a message to register the screenshot in the data file so as to play with gaze overlay  
    screenshotName = 'screenshots/' + expInfo['SubjectNO'] + '_' + expInfo['SubjectInitials'] + '_' + cond + '.jpg'
    img2drop.save(screenshotName)
    
    # start recording
    tk.setOfflineMode()
    pylink.pumpDelay(50)
    error = tk.startRecording(1,1,1,1)
    pylink.pumpDelay(100) # wait for 100 ms to make sure data of interest is recorded
    
    # show the image 
    img.draw()  
    win.flip()
    tk.sendMessage('DISPLAY_SCREEN') # this message marks the time 0 of a trial, can also send the "DISPLAY_SCREEN" message here
    
    # send a message to register the image to be loaded into DV later on, see DV manual-> "Protocol for EyeLink Data to Viewer Integration"
    # path relative to where you save your EDF data file
    tk.sendMessage('!V IMGLOAD FILL ./../%s' % screenshotName) 
    
    # define an interest area by sending a message to the tracker
    tk.sendMessage('!V IAREA RECTANGLE 1 240 212 1040 812 image_region')

    # draw a rectangle on the host PC to show where the interest area is
    tk.sendCommand('draw_box 240 212 1040 812 6')
    
    #determine which eye(s) are available
    eyeTracked = tk.eyeAvailable() 
    
    # show the image indefinitely or press a key to terminate a trial
    gazePos =  (scnWidth/2, scnHeight/2)
    terminate = False
    while not terminate:
        # check for keypress to terminate a trial
        if len(event.getKeys())>0: # KEYBOARD
            terminate = True
        if True in tk.getLastButtonPress(): # GamePad connected to the tracker HOST PC
            terminate = True
            
        # check for new samples
        dt = tk.getNewestSample()
        if (dt != None):
            if eyeTracked == 1 and dt.isRightSample():
                gazePos = dt.getRightEye().getGaze()
            elif eyeTracked == 0 and dt.isLeftSample():
                gazePos = dt.getLeftEye().getGaze()
            cursor.pos = (gazePos[0]-scnWidth/2, scnHeight/2-gazePos[1])
        img.draw()
        cursor.draw()
        win.flip()
        
    # clear the subject display
    win.color=[0,0,0]
    win.flip()
    
    # clear the host display
    tk.sendCommand('clear_screen 0') 

    # send trial variables for Data Viewer integration
    tk.sendMessage('!V TRIAL_VAR cond %s' %cond)

    # send a message to mark the end of trial
    tk.sendMessage('TRIAL_RESULTS 0')
    pylink.pumpDelay(100)
    tk.stopRecording() # stop recording


#### STEP VIII: The real experiment starts here ##########################################

# show some instructions here.
msg = visual.TextStim(win, text = 'Camera calibration!', color = 'black', units = 'pix')
msg.draw(); win.flip()
event.waitKeys()

# set up the camera and calibrate the tracker at the beginning of each block
tk.doTrackerSetup()

# run a block of trials
testList = trials[:]*1 # construct the trial list
random.shuffle(testList) # randomize the trial list
# Looping through the trial list
for t in testList: 
    runTrial(t)

# Get the EDF data and say goodbye
msg.text='Bye bye'
msg.draw(); win.flip()
tk.setOfflineMode()
tk.receiveDataFile(dataFileName, dataFolder + dataFileName)

#close the link to the tracker
pylink.closeGraphics()
win.close()
tk.close()
